-- vamos a crear una base de datos para una empresa
create database if not exists empresa;
-- voy a utilizar la base creada
 use empresa;
 -- creamos la primer tabla indpendiente a partir del modelo MER
 create table if not exists departamentos(
 Id_departamento int unique not null primary key,
 Nombre_departamento varchar(50) not null,
 Ubicacion_departamento varchar(50) not null,
 Telefono_departamento varchar(50) not null
 );
 -- creamos la segunda tabla independiente a partir del modelo MER
 create table if not exists cargos(
 Id_cargo int unique not null primary key,
 Nombre_cargo varchar(50) not  null,
 Salario_cargo int not null,
 Nivel_cargo varchar(50) not null
 );
 -- creamos la tercer tabla independiente a partir del modelo MER
 create table if not exists empleados(
 Id_empleado int unique not null primary key,
 Id_cargo int not null,
 Id_departamento int not null,
 Primer_nombre_empleado varchar(50) not null,
 Segundo_nombre_empleado varchar(50) null,
 Primer_apellido_empleado varchar(50) not null,
 Segundo_apellido_empleado varchar(50)  null,
 Fecha_nacimiento date not null,
 Genero_empleado varchar(30) not null,
 Correo_electronico varchar(50) not null,
 Telefono_empleado varchar (15) not null,
 Fecha_contrato date not null,
 
 constraint fk_emplado_cargo foreign key(Id_cargo) references cargos(Id_cargo),
 constraint fk_emplado_departamento foreign key(Id_departamento) references departamentos(Id_departamento)
 );
 -- creamos la cuarta tabla indpendiente a partir del modelo MER
 create table if not exists proyectos(
 Id_proyecto int unique not null primary key,
 Nombre_proyecto varchar(50) not null,
 Fecha_inicio date not null,
 Estado_proyecto varchar(50),
 Fecha_final date not null
 );
 -- creamos la quinta tabla dependiente a partir del modelo MER
 create table if not exists empleadosproyectos(
 Id_empleadoproyecto int unique not null primary key,
 Id_empleado int  not null,
 Id_proyecto int not null,
 
 constraint fk_empleadoproyecto_empleado foreign key(Id_empleado) references empleados(Id_empleado),
 constraint fk_empleadoproyecto_proyecto foreign key(Id_proyecto) references proyectos(Id_proyecto)
 );
