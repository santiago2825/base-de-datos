-- hacemos la consulta de los empleados de la empresa
select * from empleados;
-- hacemos la consulta y mostramos solo los nombres, apellidos y el correo electronico
select 
 Primer_nombre_empleado,
 Segundo_nombre_empleado, 
 Primer_apellido_empleado,
 Segundo_apellido_empleado,
 Correo_electronico
 from empleados;
 -- hacemos la consulta de los empleados del departamento de TI
 select * from empleados where Id_departamento = 2;
 -- hacemos la consulta de los empleados de genero femenino del departamento de TI
 select * from empleados where Id_departamento = 2 And Genero_empleado ='femenino';
 -- hacemos la consulta de los empleados del departamento de TI y  Marketing
 select * from empleados where Id_departamento = 2 or Id_departamento=1;
 -- se hace la consulta de los empleados que comienza el apellido con M
 select * from empleados where Primer_apellido_empleado like 'm%';
 -- hacemos la consulta de los empleados contratatos entre el año 2020 y 2022
 select * from empleados where Fecha_contrato between '2020-01-01' and '2022-12-31';
 -- hacemos la consulta de los salarios de los cargos mayor 4000000
 select * from cargos where salario_cargo > 4000000;
 -- haceos la consulta de los empleados nacidos despues de 1990
 select * from empleados where Fecha_nacimiento > '1990-01-31';
 -- hacemos la consulta de empleados que comienze con la letra s y que sea del departamento de contabilidad
 select * from empleados where primer_nombre_empleado like 's%' and Id_departamento = 5;