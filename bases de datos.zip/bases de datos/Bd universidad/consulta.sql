SELECT * FROM estudiantes;

SELECT * FROM profesores;

SELECT * FROM cursos;

SELECT * FROM matriculas;