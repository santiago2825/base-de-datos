-- VAMOS A CREAR UNA BASE DE DATOS PARA UNA UNIVERSIDAD
CREATE DATABASE IF NOT EXISTS universidad;
USE universidad;
-- creamos la primer tabla independiente del modelo MER
CREATE TABLE IF NOT EXISTS estudiantes(
Id_estudiante INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR(50) NOT NULL,
Apellido VARCHAR(50) NOT NULL,
Correo_electronico VARCHAR(100) NOT NULL
);
-- creamos la segunda tabla independiente  del modelo MER
CREATE TABLE IF NOT EXISTS profesores (
Id_profesor INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR(50) NOT NULL,
Especialidad VARCHAR(50) NOT NULL 
);
-- creamos la tercer tabla indpendiente del modelo mer
CREATE TABLE IF NOT EXISTS cursos (
Id_curso INT UNIQUE NOT NULL PRIMARY KEY,
Id_profesor INT NOT NULL,
Nombre VARCHAR(50) NOT NULL,
Creditos INT NOT NULL,

CONSTRAINT fk_curso_profesor FOREIGN KEY (Id_profesor) REFERENCES profesores(Id_profesor)
);
CREATE TABLE IF NOT EXISTS matriculas(
Id_matricula INT UNIQUE NOT NULL PRIMARY KEY,
Id_estudiante INT NOT NULL,
Id_curso INT NOT NULL,

CONSTRAINT fk_matricula_estudiante FOREIGN KEY (Id_estudiante) REFERENCES estudiantes(Id_estudiante),
CONSTRAINT fk_matricula_curso FOREIGN KEY (Id_curso) REFERENCES cursos(Id_curso)
);
