-- creamos la data para la base de datos de estudiantes
INSERT INTO estudiantes(Id_estudiante, Nombre, apellido, Correo_electronico)VALUES
(1,"santiago","chilito","quisoboni12@gmail.com"),
(2,"nicolas"," quisoboni","nicolas@gmail.com"),
(3,"emerson","torres","emerson23@gmail.com"),
(4,"samuel","cruz","samuel1@gmail.com");

-- creamos la data para la base de datos de profesores
INSERT INTO profesores(Id_profesor, Nombre, Especialidad)VALUES
(5,"eduardo","ingenieria de software"),
(4,"adrian","gestion de proyectos"),
(3,"esteban","salud ocupocional"),
(2,"duban","contabilidad y finanzas");

-- creamos la data para la base de datos de cursos
INSERT INTO cursos(Id_curso, Id_profesor, Nombre, creditos)VALUES
(9,5,"logica de programacion",12),
(8,4,"requerimientos",23),
(7,3,"higiene industrial",42),
(6,2,"contabilidad financiera",11);

-- creamos la data para la base de datos de matricula
INSERT INTO matriculas(Id_matricula, Id_estudiante, Id_curso)VALUES
(4,1,9),
(6,2,8),
(5,3,7),
(2,4,6);

