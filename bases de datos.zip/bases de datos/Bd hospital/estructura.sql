CREATE DATABASE IF NOT EXISTS hospital;
use hospital;
CREATE TABLE IF NOT EXISTS pacientes(
Num_historia INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_paciente VARCHAR(50) NOT NULL,
Telefono BIGINT NOT NULL,
Direccion VARCHAR(50) NOT NULL
);
-- creo la segunda tabla independiente a partir del modelo MER
CREATE TABLE IF NOT EXISTS Medicos(
Num_colegiatura INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_medico VARCHAR(50) NOT NULL,
Especialidad VARCHAR(50) NOT NULL
);
-- creo la tabla cita que es semidependiente ya que contiene una llaves foraneas
CREATE TABLE IF NOT EXISTS citas(
Fecha_consulta DATE NOT NULL,
Num_historia INT NOT NULL,
Num_colegiatura INT NOT NULL,
Hora_consulta TIME NOT NULL,

PRIMARY KEY (Fecha_consulta, Hora_consulta, Num_colegiatura),
CONSTRAINT fk_cita_paciente FOREIGN KEY (Num_historia) REFERENCES pacientes(Num_historia),
CONSTRAINT fk_cita_medico FOREIGN KEY (Num_colegiatura) REFERENCES medicos(Num_colegiatura)
);

