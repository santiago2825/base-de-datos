-- voy a crear la data para la base de datos hospital para los pacientes
INSERT INTO pacientes(Num_historia, Nombre_paciente, Telefono, Direccion) VALUES
(101,"Kevin Adrada", 3207569023,"Cl 2N #2-46"),
(102,"Natalia Diaz", 3182987195,"Cra 5 #31-22"),
(103,"Cristian Obando", 3235968648 ,"Cl 8N #5-18"),
(104,"Marcela Lopez", 3215439571,"Cra 4 #4-21");

-- voy a crear la data para la base de datos hospital para los medicos
INSERT INTO medicos(Num_colegiatura, Nombre_medico, Especialidad) VALUES
(123,"Santiago Muñoz","Pediatria"),
(456,"Angie Villota","Psiquiatria"),
(789,"Duvan Bolaños","Cardiologia"),
(741,"Marcela Lopez","Dermatologia");

-- voy a crear la data para la base de datos hospital para las citas
INSERT INTO citas(Fecha_consulta, Num_historia, Num_colegiatura, Hora_consulta) VALUES
('2024-07-16',101,123,'12:30:00'),
('2025-11-05',103,789,'14:45:00'),
('2025-06-30',102,456,'08:00:00'),
('2025-03-24',104,741,'10:15:00');
