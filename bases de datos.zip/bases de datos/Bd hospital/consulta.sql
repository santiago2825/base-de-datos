-- consultas para la verificacion de datos
SELECT * FROM pacientes;

SELECT * FROM medicos;

SELECT * FROM citas;
