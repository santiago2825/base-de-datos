-- vamos a crear una base de datos de una biblioteca
CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;
-- creamos la primer tabla independiente para la primer entidad idenpendiente del modelo MER
 CREATE TABLE IF NOT EXISTS usuarios(
 Id_usuario INT UNIQUE NOT NULL PRIMARY KEY,
 Nombre VARCHAR(50) NOT NULL,
 Direccion VARCHAR (50) NULL
);

-- CREAMOS LA SEGUNDA TABLA INDEPENDIENTE PARA LA SEGUNA ENTIDAD INDEPENDIENTE DEL MODELO MER
CREATE TABLE IF NOT EXISTS libros(
Id_libro INT UNIQUE NOT NULL PRIMARY KEY,
Titulo  VARCHAR(50) NOT NULL,
Autor  VARCHAR(50) NULL,
Año_publicado DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS prestamos(
Fecha_prestamo DATE UNIQUE NOT NULL PRIMARY KEY,
Id_usuario INT NOT NULL,
Id_libro INT NOT NULL,
Fecha_devolucion DATE NOT NULL,
Libros_prestados INT NOT NULL,

CONSTRAINT fk_prestamo_usuario FOREIGN KEY (Id_usuario) REFERENCES usuarios(Id_usuario),
CONSTRAINT fk_prestamo_libro FOREIGN KEY (Id_libro) REFERENCES libros(Id_libro)

);
