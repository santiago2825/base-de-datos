SELECT * FROM usuarios;

SELECT * FROM libros;

SELECT * FROM prestamos;