-- CREAMOS LA DATA PARA LA BASE DE DATOS PARA LOS USUARIOS
INSERT INTO usuarios(Id_usuario, Nombre, Direccion) VALUES
(1,"Santiago","Cr 10 #34-21"),
(2,"nicolas","Cr 42 #76-1"),
(3,"emerson","Cr 4 #7-132"),
(4,"stiven","Cr 5 #76-11"),
(5,"camilo","Cr 13 #6-112");

-- CREAMOS LA DATA PARA LA BASE DE DATOS PARA LOS LIBROS
INSERT INTO libros(Id_libro, Titulo, Autor, Año_publicado)VALUES
(1,"cien años de soledad", "Gabriel Garcia Marquez",'1967-04-02'),
(2,"Don Quijote de la mancha","Miguel de Cervantes",'1605-03-06'),
(3,"El principito","Antonie de Saint-Exupery",'1943-11-23'),
(4,"La sombra del Viento","carlos Ruiz Zafon",'2001-07.14'),
(5,"Rayuela","Julio Cortaz",'1963-09-17');

-- creamos la data de la base  de datos dependiente para prestamos
INSERT INTO prestamos(Fecha_prestamo, Id_usuario, Id_libro, Fecha_devolucion, Libros_prestados)VALUES
('2025-06-05',1,5,'2025-08-02',2),
('2023-04-12',5,1,'2025-06-02',1),
('2022-12-01',2,3,'2026-02-02',4),
('2024-01-01',3,2,'2025-03-12',6),
('2020-02-28',4,4,'2025-05-17',2);
