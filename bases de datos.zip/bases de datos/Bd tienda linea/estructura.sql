CREATE DATABASE IF NOT EXISTS tienda;
use tienda;
-- creamos la primera tabla independiente del modelo MER
CREATE TABLE IF NOT EXISTS clientes(
Id_cliente INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR(50) NOT NULL,
Apellido VARCHAR(50) NOT NULL,
Correo_electronico VARCHAR(50) NOT NULL
);
-- creamos la segunda tabla independiente del modelo MER
CREATE TABLE IF NOT EXISTS productos(
Id_producto INT UNIQUE NOT NULL PRIMARY KEY,
Nombre VARCHAR(50) NOT NULL,
Descripcion VARCHAR(150) NOT NULL,
Precio DECIMAL(10,2) NOT NULL
);
-- creamos la tercer tabla semidependiente del modelo MER
CREATE TABLE IF NOT EXISTS pedidos(
Id_pedido INT UNIQUE NOT NULL PRIMARY KEY,
Id_cliente INT NULL,
Numeros_unidades INT NOT NULL,
Fecha_pedido DATE NOT NULL,

CONSTRAINT fk_pedido_cliente FOREIGN KEY (Id_cliente) REFERENCES clientes(Id_cliente)
);
-- creamos una tabla dependiente del modelo MER
CREATE TABLE IF NOT EXISTS facturas(
Id_factura INT UNIQUE NOT NULL PRIMARY KEY,
Id_cliente INT NOT NULL,
Id_producto INT NOT NULL,
Id_pedido INT NOT NULL,

CONSTRAINT fk_factura_cliente FOREIGN KEY (Id_cliente) REFERENCES clientes(Id_cliente),
CONSTRAINT fk_factura_producto FOREIGN KEY (Id_producto) REFERENCES productos(Id_producto),
CONSTRAINT fk_factura_pedido FOREIGN KEY (Id_pedido) REFERENCES pedidos(Id_pedido)
);
