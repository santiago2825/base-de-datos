-- creamos la data de la base de datos de clientes
INSERT INTO clientes(Id_cliente, Nombre, Apellido, Correo_electronico)VALUES
(1,"santiago","chilito","quisoboni12@gmail.com"),
(2,"nicolas"," quisoboni","nicolas@gmail.com"),
(3,"emerson","torres","emerson23@gmail.com"),
(4,"samuel","cruz","samuel1@gmail.com");
-- creamos la data de la base de datos de productos
INSERT INTO productos(Id_producto, Nombre, Descripcion, Precio)VALUES
(11,"shampoo Bioherbal"," shampoo elaborado extracto de romero y aloe vera.","18900"),
(22,"cafe organico sierra verde","cafe 100% colombiano,tostado medio, con aroma intenso y sabor balanceado","22500"),
(33,"Audífonos Bluetooth JBL Tune 510BT","Auriculares inalámbricos con sonido potente, micrófono integrado y hasta 40 horas de batería.","49900"),
(44,"Mouse Inalámbrico Logitech M170","Mouse óptico inalámbrico con conexión USB, diseño ergonómico y batería de larga duración.","50000");

-- creamos la data de la base de datos de pedidos
INSERT INTO pedidos(Id_pedido, Id_cliente, Numeros_unidades, Fecha_pedido)VALUES
(01,1,"54",'2025-06-12'),
(02,2,"20",'2025-04-11'),
(03,3,"5",'2025-02-22'),
(05,4,"12",'2025-01-01');

-- creamos la data de la base de datos de facturas
INSERT INTO facturas(Id_factura, Id_cliente, Id_producto, Id_pedido)VALUES
(99,1,11,01),
(88,2,33,02),
(77,3,22,03),
(66,4,44,05);